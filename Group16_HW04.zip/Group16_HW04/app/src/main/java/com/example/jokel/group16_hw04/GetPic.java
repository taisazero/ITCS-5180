package com.example.jokel.group16_hw04;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */

public class GetPic extends AsyncTask<String,Integer,Bitmap> {
    ImageView pic;
    ProgressBar pb;
    public GetPic(ImageView pic, ProgressBar pb){
        this.pic=pic;
        this.pb=pb;

    }
    @Override
    protected void onPreExecute(){
        pb.setMax(100);
        pb.setVisibility(View.VISIBLE);
        pic.setVisibility(View.GONE);
        pb.setProgress(0);
        pb.refreshDrawableState();
    }
    @Override
    protected void onProgressUpdate(Integer...values){
        for (int i= values[0];i<100;i++) {
            pb.setProgress(i);
            Thread t=new Thread();
            try {
                t.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    protected Bitmap doInBackground(String... strings) {
        Bitmap image;
        try{

            URL link=new URL (strings[0]);
            HttpURLConnection connection=(HttpURLConnection)link.openConnection();
            try {
                connection.setDoInput(true);
                connection.setDoOutput(true);
                publishProgress(1);
                connection.connect();



                image = BitmapFactory.decodeStream(connection.getInputStream());
                Log.d("Image is:", image.toString());
                connection.disconnect();
            }
            finally {
                connection.disconnect();
            }
            return image;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(Bitmap m){




        if(m!=null)
            pic.setImageBitmap(m);
        else{
            Log.d("Image","null Picture");
        }
        Log.d("Image Loading",pic.toString());
        pb.setVisibility(View.INVISIBLE);
        pic.setVisibility(View.VISIBLE);
        pic.refreshDrawableState();
    }


}