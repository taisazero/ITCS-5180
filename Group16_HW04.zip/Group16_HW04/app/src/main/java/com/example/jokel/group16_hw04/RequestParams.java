package com.example.jokel.group16_hw04;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */
public class RequestParams {
    String method, baseURL;
    HashMap<String,String> params=new HashMap<String,String>();
    public  RequestParams(String method,String baseURL){
        super();
        this.baseURL=baseURL;
        this.method=method;
    }
    public void addParam(String key,String value){
        params.put(key,value);
    }
    public String getEncodedParams(){
       StringBuilder sb=new StringBuilder();
        for (String key: params.keySet()){
            try {
                String value= URLEncoder.encode(params.get(key),"UTF-8");
                if(sb.length()>0){
                    sb.append("&");
                }
                sb.append(key+"="+value);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
    public String getEncodedUrl(){
        return this.baseURL+"?"+getEncodedParams();
    }
    public HttpURLConnection setUpConnection() throws IOException {
        if (method.equals("GET")){
            URL link= new URL(getEncodedUrl());
            HttpURLConnection con=(HttpURLConnection)link.openConnection();
            con.setRequestMethod("GET");
            return con;
        }
        else{
            URL link= new URL(this.baseURL);
            HttpURLConnection con=(HttpURLConnection)link.openConnection();
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            OutputStreamWriter w=new OutputStreamWriter(con.getOutputStream());
            w.write(getEncodedParams());
            w.flush();
            return con;
        }
    }
}
