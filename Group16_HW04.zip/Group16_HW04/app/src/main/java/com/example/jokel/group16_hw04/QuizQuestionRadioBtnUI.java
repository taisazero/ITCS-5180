package com.example.jokel.group16_hw04;

import android.content.Context;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */
public class QuizQuestionRadioBtnUI extends android.support.v7.widget.AppCompatRadioButton {

    public QuizQuestionRadioBtnUI(Context context) {
        super(context);
    }
    public boolean isCorrect;

    public int ID;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isCorrect() {
        return isCorrect;
    }

    public void setCorrect(boolean correct) {
        isCorrect = correct;
    }
}
