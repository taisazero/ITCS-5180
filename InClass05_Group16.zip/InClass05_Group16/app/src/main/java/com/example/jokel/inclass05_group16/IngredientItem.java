package com.example.jokel.inclass05_group16;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatCallback;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by Zero on 9/25/2017.
 */

public class IngredientItem extends LinearLayout {
    public static int id=107;
    public EditText ingredient;
    public ImageButton add;
    public ImageButton remove;

    public IngredientItem(final Context context) {
        super(context);
        inflateXML(context);
}

    private void inflateXML(Context context) {

            LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View itemView = inflater.inflate(R.layout.ingredients,this);
            ingredient=(EditText)findViewById(R.id.ingredient);
            add=(ImageButton)findViewById(R.id.add);
            remove=(ImageButton)findViewById(R.id.remove);





    }
    }