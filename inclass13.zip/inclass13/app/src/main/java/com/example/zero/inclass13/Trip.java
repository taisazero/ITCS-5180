package com.example.zero.inclass13;

import java.util.ArrayList;

/**
 * Created by Zero on 12/4/2017.
 */

public class Trip {
    private double cost;
    private String name;
    private ArrayList<Place> list;


    public Trip() {
    }

    public Trip(double cost, String name, ArrayList<Place> list) {
        this.cost = cost;
        this.name = name;
        this.list = list;

    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Place> getList() {
        return list;
    }

    public void setList(ArrayList<Place> list) {
        this.list = list;
    }
}
