package com.example.jokel.group16_hw04;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */
public class StatsActivity extends AppCompatActivity {

    public static double stat = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        if (getIntent() != null) {

            if (getIntent().getSerializableExtra("ID") == EnumActivity.ACTIVITY_STATS) {
                if (Question.getTotalNumberCorrect() != 0) {
                    stat = TriviaActivity.totalNumberCorrect / Question.getTotalNumberCorrect();
                    stat = (int)(stat * 1000);
                    stat /= 10;
                } else {
                    stat = 0;
                }
                setViews();
                setButtonHandlers();
            }
        }
    }

    public void setViews() {

        TextView txtPercent = (TextView) findViewById(R.id.txtCorrectPercent);
        txtPercent.setText(stat + "%");

        ProgressBar pgbPercent = (ProgressBar) findViewById(R.id.pgbCorrect);
        pgbPercent.setMax(Question.getTotalNumberCorrect());
        pgbPercent.setProgress((int)TriviaActivity.totalNumberCorrect, true);

        TextView txtDescription = (TextView) findViewById(R.id.txtStatsDescription);

        if (stat == 100) {
            txtDescription.setText("Congrats qq ;u; you sure know a lot!");
        }

        if (stat > 75) {
            txtPercent.setTextColor(Color.GREEN);
            pgbPercent.setProgressTintList(ColorStateList.valueOf(Color.GREEN));
            txtDescription.setText("Try again and see if you can get all the correct answers!");
        } else if (stat < 75 && stat > 25) {
            txtPercent.setTextColor(Color.parseColor("#FF9500"));
            pgbPercent.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#FF9500")));
            txtDescription.setText("You need more practice!!");
        } else {
            txtPercent.setTextColor(Color.RED);
            pgbPercent.setProgressTintList(ColorStateList.valueOf(Color.RED));
            txtDescription.setText("Wow you did not perform well at all...");
        }
    }

    public void setButtonHandlers() {

        Button btnQuit = (Button) findViewById(R.id.btnQuit);
        btnQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Button btnTryAgain = (Button) findViewById(R.id.btnTryAgain);
        btnTryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StatsActivity.this, TriviaActivity.class);
                intent.putExtra("ID", EnumActivity.ACTIVTY_START);
                startActivity(intent);
                finish();

            }
        });

    }
}
