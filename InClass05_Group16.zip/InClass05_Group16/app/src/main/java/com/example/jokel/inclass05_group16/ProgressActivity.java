package com.example.jokel.inclass05_group16;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 1.0 9/25/2017
 *
 */
public class ProgressActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        int id;
        Log.d("ProgressActivity:", "onCreate:check intent");
        if (getIntent() != null) {
            Log.d("ProgressActivity:", "onCreate:intent not null");
            createProgressBar();
            id = getIntent().getExtras().getInt("ID");

            if (id == MainActivity.ACTIVITY_SEARCH) {
                Log.d("ProgressActivity:", "onCreate:ACTIVITY_SEARCH");
                RecipePuppyHandler recipeHandler = new RecipePuppyHandler();
                recipeHandler.setContext(ProgressActivity.this);

                RequestParams params = new RequestParams("GET", "http://www.recipepuppy.com/api/");

                StringBuilder ingredients = new StringBuilder();
                Log.d("ProgressActivity:", "onCreate:ACTIVITY_SEARCH:ingredients");
                for (int i = 0; i < Recipe.getSearchIngredients().size(); i++) {
                    ingredients.append(Recipe.getSearchIngredients().get(i));
                    if (i != Recipe.getSearchIngredients().size()) {
                        ingredients.append(",");
                    }
                }
                Log.d("ProgressActivity:", "onCreate:ACTIVITY_SEARCH:ingredients:" + ingredients.toString());
                params.addParam("i", ingredients.toString());
                params.addParam("q", Recipe.getSearchName());
                Log.d("ProgressActivity:", "onCreate:ACTIVITY_SEARCH:params:" + params.toString());

                recipeHandler.execute(params);

                ProgressBar i = (ProgressBar)findViewById(R.id.barProgressBar);
            } else {
                finish();
            }

        } else {
            finish();
        }
    }

    public void createProgressBar() {
        Log.d("ProgressActivity:", "createProgressBar:setting");

    }
}
