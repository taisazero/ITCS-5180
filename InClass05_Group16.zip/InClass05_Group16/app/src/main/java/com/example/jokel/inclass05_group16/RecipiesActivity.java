package com.example.jokel.inclass05_group16;

import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 1.0 9/25/2017
 *
 */
public class RecipiesActivity extends AppCompatActivity {

    public static int num = 0;
    int size;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.recipedisplay);

        TextView URL = (TextView) this.findViewById(R.id.URLView);
        TextView title = (TextView) this.findViewById(R.id.title);
        ImageView image = (ImageView) this.findViewById(R.id.imageView);
        TextView ing = (TextView) this.findViewById(R.id.ingredientsList);

        ArrayList<Recipe> list = Recipe.getRecipes();

        Recipe r = list.get(num);
        size=list.size();
        if (r.getThumbnail() != null && !r.getThumbnailURL().equals("")) {
            Log.d("Recipes", r.getThumbnailURL());
            image.setImageBitmap(r.getThumbnail());
        }
        if (!r.getHref().equals(""))
            URL.setText(r.getHref());
        URL.setClickable(true);
        title.setText(title.getText() + " " + r.getName());
        ing.setText(r.getIngredients());

        setHandlers();


    }

    public void setHandlers() {

        Button finish = (Button) this.findViewById(R.id.finishBtn);
        ImageButton pre = (ImageButton) this.findViewById(R.id.previous);
        ImageButton next = (ImageButton) this.findViewById(R.id.next);
        ImageButton first = (ImageButton) this.findViewById(R.id.first);
        ImageButton last = (ImageButton) this.findViewById(R.id.last);
        TextView URL = (TextView) this.findViewById(R.id.URLView);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();

            }
        });

        pre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(RecipiesActivity.num>0) {
                    RecipiesActivity.num = RecipiesActivity.num - 1;
                }
                Intent i =new Intent(RecipiesActivity.this,RecipiesActivity.class);
                RecipiesActivity.this.startActivity(i);
                RecipiesActivity.this.finish();



            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(RecipiesActivity.num<size-1) {
                    RecipiesActivity.num = RecipiesActivity.num + 1;
                }
                Intent i =new Intent(RecipiesActivity.this,RecipiesActivity.class);
                RecipiesActivity.this.startActivity(i);
                RecipiesActivity.this.finish();



            }
        });
        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecipiesActivity.num=0;
                Intent i =new Intent(RecipiesActivity.this,RecipiesActivity.class);
                RecipiesActivity.this.startActivity(i);
                RecipiesActivity.this.finish();



            }
        });
        last.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecipiesActivity.num=size-1;
                Intent i =new Intent(RecipiesActivity.this,RecipiesActivity.class);
                RecipiesActivity.this.startActivity(i);
                RecipiesActivity.this.finish();



            }
        });
        final String U=URL.getText().toString();
        URL.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    Intent i =new Intent(Intent.ACTION_VIEW, Uri.parse(U));
                    startActivity(i);

                }
            }
        );


    }
}