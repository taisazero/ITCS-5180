package com.example.jokel.hw06;

import android.app.FragmentManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.jokel.hw06.db.Course;
import com.example.jokel.hw06.db.Instructor;
import com.example.jokel.hw06.db.User;
import com.example.jokel.hw06.fragments.AddInstructorFragment;
import com.example.jokel.hw06.fragments.CourseManagerFragment;
import com.example.jokel.hw06.fragments.CreateCourseFragment;
import com.example.jokel.hw06.fragments.LoginFragment;
import com.example.jokel.hw06.fragments.SignUpFragment;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;
import io.realm.exceptions.RealmPrimaryKeyConstraintException;

public class MainActivity extends AppCompatActivity implements LoginFragment.OnFragmentInteractionListener,
        SignUpFragment.OnFragmentInteractionListener, CourseManagerFragment.OnFragmentInteractionListener,
        AddInstructorFragment.OnFragmentInteractionListener, CreateCourseFragment.OnFragmentInteractionListener, InstructorUI.OnFragmentInteractionListener {

    public Realm realm;
    public boolean isLoggedIn;
    public static ArrayList<Instructor> instructorArrayList = new ArrayList<>();
    public  static ArrayList<Course> courseArrayList = new ArrayList<>();
    public static FragmentManager fm;
    public static FragmentManager getF(){
        return fm;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fm=getFragmentManager();
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        Realm.init(this);
       //Realm.deleteRealm(Realm.getDefaultConfiguration()); // TODO remove

        isLoggedIn = false;

        getFragmentManager().beginTransaction()
                .add(R.id.container, new LoginFragment(), "loginFragment")
                .commit();
    }

    @Override
    public void gotoNextFragment() {
        if (LoginFragment.flagLogin) {
            LoginFragment.flagLogin = false;
            final String username = LoginFragment.editEmail.getText().toString();
            final String password = LoginFragment.editPassword.getText().toString();

            realm = Realm.getDefaultInstance();
            try {
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        /*User user = realm.createObject(User.class, username);
                        user.setPassword(editWebsite);*/
                    }
                });

                RealmResults<User> users = realm.where(User.class)
                        .equalTo("username", username)
                        .equalTo("password", password).findAll();

                Log.d("MainActivity", "gotoNextFragment:" + users.toString());
                if (users.size() != 0) {
                    Log.d("MainActivity", "gotoNextFragment:user is valid");
                    CreateCourseFragment.loggedUser=users.first().getUsername();
                    CourseManagerFragment.user=users.first().getUsername();
                    getFragmentManager().beginTransaction()
                            .replace(R.id.container, new CourseManagerFragment(), "courseManagerFragment")
                            .commit();
                    isLoggedIn = true;
                } else {
                    Log.d("MainActivity", "gotoNextFragment:user is not valid");

                    Toast.makeText(this,"Username or Password are incorrect",Toast.LENGTH_LONG).show();
                }


            }finally {
                realm.close();
            }
        } else if (CourseManagerFragment.flagAddCourse) {
            CourseManagerFragment.flagAddCourse = false;

            Log.d("MainActivity", "gotoNextFragment:flagAddCourse is true");
            getFragmentManager().beginTransaction()
                    .replace(R.id.container, new CreateCourseFragment(), "createCourseFragment")
                    .commit();
        } else if (CreateCourseFragment.flagCreateCourse) {
            CreateCourseFragment.flagCreateCourse = false;
            getFragmentManager().beginTransaction()
                    .replace(R.id.container, new CourseManagerFragment(), "courseManagerFragment")
                    .commit();

        }
        else if (LoginFragment.flagSignUpNavigation) {
            LoginFragment.flagSignUpNavigation=false;

            getFragmentManager().beginTransaction()
                    .replace(R.id.container, new SignUpFragment(), "signUpFragment")
                    .commit();


    }

    else if (SignUpFragment.done){
            SignUpFragment.done=false;
            try {
                realm = Realm.getDefaultInstance();
                final String fName = SignUpFragment.editFirstName.getText().toString();
                final String password = SignUpFragment.password.getText().toString();
                final String lName = SignUpFragment.editLastName.getText().toString();
                final String username = SignUpFragment.userNameSignUp.getText().toString();
                final byte[] pic = SignUpFragment.byteArray;
                try {
                    realm.executeTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(Realm realm) {
                            User user = realm.createObject(User.class, username);
                            user.setPassword(password);
                            user.setPicture(pic);
                            user.setfName(fName);
                            user.setlName(lName);

                        }
                    });

                } finally {
                    realm.close();

                }

                getFragmentManager().beginTransaction()
                        .replace(R.id.container, new LoginFragment(), "loginFragment")
                        .commit();
            } catch (RealmPrimaryKeyConstraintException e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT);
            }
        }else if (AddInstructorFragment.done){
            AddInstructorFragment.done=false;
            realm = Realm.getDefaultInstance();
            final String fName = AddInstructorFragment.editFirstName.getText().toString();
            final String lName= AddInstructorFragment.editLastName.getText().toString();
            final String email = AddInstructorFragment.editEmail.getText().toString();
            final String website= AddInstructorFragment.editWebsite.getText().toString();
            final byte[] pic;
            boolean success = true;
            try {
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        Instructor user = realm.createObject(Instructor.class, fName +" "+ lName);
                        user.setfName(fName);
                        user.setlName(lName);
                        user.setPicture(AddInstructorFragment.byteArray);
                        user.setEmail(email);
                        user.setUrl(website);

                    }
                });

            } catch (IllegalArgumentException e) {
                Toast.makeText(this, "Message: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                success = false;
            }
            finally{
                realm.close();

            }
            if (success) {

                getFragmentManager().beginTransaction()
                        .replace(R.id.container, new CourseManagerFragment(), "courseManagerFragment")
                        .commit();
            }
        }
        else if (AddInstructorFragment.edit){
            AddInstructorFragment.edit=false;
            InstructorUI.updateAdapter();
            getFragmentManager().beginTransaction()
                    .replace(R.id.container, new CourseManagerFragment(), "courseManagerFragment")
                    .commit();


        }
    }
    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            //HomeFragment.clearField();
            getFragmentManager().popBackStack();
            //HomeFragment.clearField();
        }else {
            //HomeFragment.clearField();
            super.onBackPressed();
            //HomeFragment.clearField();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (isLoggedIn) {
            switch (id) {
                case R.id.action_home:
                    getFragmentManager().beginTransaction()
                            .replace(R.id.container, new CourseManagerFragment(), "courseManagerFragment")
                            .commit();
                    break;
                case R.id.action_instructors:
                    getFragmentManager().beginTransaction()
                            .replace(R.id.container, new InstructorUI(), "InstructorUI")
                            .commit();
                    break;
                case R.id.action_add_instructor:
                    getFragmentManager().beginTransaction()
                            .replace(R.id.container, new AddInstructorFragment(), "addInstructorFragment")
                            .commit();
                    break;
                case R.id.action_logout:
                    isLoggedIn = false;
                    getFragmentManager().beginTransaction()
                            .replace(R.id.container, new LoginFragment(), "loginFragment")
                            .commit();
                    break;
                case R.id.action_exit:
                    isLoggedIn = false;
                    onBackPressed();
                    break;
            }
        } else {
            switch (id) {
                case R.id.action_exit:
                    isLoggedIn = false;
                    onBackPressed();
                    break;
            }
            Toast.makeText(this, "You need to be logged in!", Toast.LENGTH_SHORT).show();
        }


        return super.onOptionsItemSelected(item);
    }
}

