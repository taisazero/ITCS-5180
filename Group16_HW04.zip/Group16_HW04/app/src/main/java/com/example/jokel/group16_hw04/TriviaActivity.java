package com.example.jokel.group16_hw04;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */
public class TriviaActivity extends AppCompatActivity {

    public static int questionsID;
    public static int questionIndex;
    public static int currentQuestionLocation;
    public static int totalNumberOfQuestions;
    public static double totalNumberCorrect;
    static TextView timer;
     static CountDownTimer ct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
        Log.d("TriviaActivity", "onCreate");
        timer=(TextView)findViewById(R.id.txtTime);

        if (getIntent() != null) {
            totalNumberOfQuestions = Question.questions.size();
            Log.d("TriviaActivity", "onCreate:intent not null");

            // TODO check if it works
            if (getIntent().getSerializableExtra("ID") == EnumActivity.ACTIVTY_START) {
                Log.d("TriviaActivity", "onCreate:ACTIVTY_START");

                questionIndex = 1;
                totalNumberCorrect = 0;
                currentQuestionLocation = 0;
                setCurrentQuestion(currentQuestionLocation++);
                setButtonHanders();

            } else if (getIntent().getSerializableExtra("ID") == EnumActivity.ACTIVTY_NEXT) {
                Log.d("TriviaActivity", "onCreate:ACTIVTY_NEXT");
                // TODO may need to pass info if the activity is being destroyed
                questionIndex++;
                setCurrentQuestion(currentQuestionLocation++);

                setButtonHanders();
            }else {
                Log.d("TriviaActivity", "onCreate:finishing");
                finish();

            }
        } else {
            Log.d("TriviaActivity", "onCreate:finishing");
            finish();
        }
    }

    public boolean isConnected(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info=cm.getActiveNetworkInfo();
        if(info!=null && info.isConnected())
        return  true;
        return false;
    }



    public void setCurrentQuestion(int slot) {

        /*TODO add code for just in case the slot goes out of the range
          it should go ahead and finish the activity here
         */
        Question question = Question.questions.get(slot);
        // Set Question Num
        TextView txtQuestionId = (TextView) findViewById(R.id.txtQuestionId);
        txtQuestionId.setText("Q" + questionIndex);





        // Set the image:
        // TODO thread this

        if(isConnected()&& !question.getImgURL().equals("")) {
            ImageView pic=(ImageView)findViewById(R.id.imgView);
            ProgressBar pb=(ProgressBar)findViewById(R.id.pgbTriviaQuestionImg) ;

            pb.setVisibility(View.VISIBLE);

            new GetPic(pic,pb).execute(question.getImgURL());

        }
        else {
            Toast.makeText(TriviaActivity.this,"Image not Found",Toast.LENGTH_LONG).show();
        }


       // ImageView img = (ImageView) findViewById(R.id.imgView);
       // img.setImageBitmap(question.getQuestionsImage());
       // img.setVisibility(View.VISIBLE);
        //img.refreshDrawableState();

        // Set the Description
        if(currentQuestionLocation==1) {
            Log.d("IMPROTANT","was here");
            TextView questionDescription = (TextView) findViewById(R.id.txtQuestionDescription);
            questionDescription.setText(question.getDescription());
            timer.setText("60");

            ct = new CountDownTimer(60 * 1000, 1000) {
                @Override
                public void onTick(long millis) {
                    timer.setText(millis / 1000 + " Seconds Remaining");
                }

                @Override
                public void onFinish() {
                    Toast.makeText(TriviaActivity.this, "Time's Up!", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(TriviaActivity.this, StatsActivity.class);
                    intent.putExtra("ID", EnumActivity.ACTIVITY_STATS);

                    ct.cancel();
                    ct = null;
                    startActivity(intent);
                    finish();
                }
            }.start();
        }

        // // TODO: 10/2/2017 fix me
        RadioGroup container = (RadioGroup) findViewById(R.id.radioContainer);
        int answerIndex = 0;
        for (int i = 0; i < question.answers.size(); i++) {
            //final QuizQuestionItemUI item = new QuizQuestionItemUI(this);
            //LinearLayout questionView = (LinearLayout)item;
            //item.setId(answerIndex);
            //item.setQuestionAnswer(answer);
            final QuizQuestionRadioBtnUI item = new QuizQuestionRadioBtnUI(this);
            item.setId(answerIndex++);
            Log.d("TriviaActivity", "setCurrentQuestion:" + question.answers.get(i) + " is " +
                    question.corrects.get(i));
            item.isCorrect = question.corrects.get(i);
            item.setText(question.answers.get(i));

            container.addView(item);
        }
        container.refreshDrawableState();
    }

    public void setButtonHanders() {
        Button btnQuit = (Button) findViewById(R.id.btnQuit);
        btnQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("TriviaActivity", "setButtonHanders:quiting");
                finish();
            }
        });

        Button btnNext = (Button) findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioGroup container = (RadioGroup) findViewById(R.id.radioContainer);
                Log.d("TriviaActivity", "setButtonHanders:next");

                double localCorrect = 0;
                Log.d("TriviaActivity", "setButtonHanders:determing correct...");
                for (int i = 0; i < container.getChildCount(); i++) {
                    final QuizQuestionRadioBtnUI item = (QuizQuestionRadioBtnUI) container.getChildAt(i);
                    Log.d("TriviaActivity", "setButtonHanders:answer:" + item.getText().toString() + " is "
                            +item.isCorrect);
                    if (item.isChecked()) {
                        if (item.isCorrect) {
                            localCorrect++;
                        } else {
                            localCorrect--;
                        }
                    }
                }

                // Empty Container
                if (container.getChildCount() > 0) {
                    Log.d("TriviaActivity", "setButtonHanders:emptying container...");
                    container.removeAllViews();
                }

                Log.d("TriviaActivity", "setButtonHanders:localCorrect: " + localCorrect);
                totalNumberCorrect += (localCorrect >= 0 ? localCorrect:0);
                Log.d("TriviaActivity", "setButtonHanders:totalNumberCorrect: " + totalNumberCorrect);

                Intent intent;
                if (questionIndex == Question.questions.size()) {
                    intent = new Intent(TriviaActivity.this, StatsActivity.class);

                    intent.putExtra("ID", EnumActivity.ACTIVITY_STATS);
                    Log.d("TriviaActivity", "setButtonHanders:ACTIVITY_STATS");
                    ct.cancel();
                    ct=null;
                    // TODO Possibly needs more

                    startActivity(intent);
                    finish();
                } else {
                    ImageView pic=(ImageView)findViewById(R.id.imgView);
                    pic.setVisibility(View.GONE);
                    questionIndex++;


                    setCurrentQuestion(currentQuestionLocation++);
                    setButtonHanders();

                    //intent = new Intent(TriviaActivity.this, TriviaActivity.class);
                    //intent.putExtra("ID", EnumActivity.ACTIVTY_NEXT);
                    //Log.d("TriviaActivity", "setButtonHanders:ACTIVTY_NEXT");
                }

            }
        });
    }

}
