package com.example.zero.finalexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class travelMap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travel_map);
    }
}
