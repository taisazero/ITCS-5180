package com.example.jokel.hw06.adapters;


import android.app.FragmentManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jokel.hw06.InstructorUI;
import com.example.jokel.hw06.MainActivity;
import com.example.jokel.hw06.R;
import com.example.jokel.hw06.db.Instructor;
import com.example.jokel.hw06.fragments.AddInstructorFragment;
import com.example.jokel.hw06.fragments.CourseManagerFragment;
import com.example.jokel.hw06.fragments.CreateCourseFragment;

import io.realm.RealmResults;

/**
 * Created by Zero on 11/9/2017.
 */

public class UIAdapter extends RecyclerView.Adapter<UIAdapter.ViewHolder>{


        RealmResults<Instructor> list;


public UIAdapter(RealmResults<Instructor> list){
        this.list=list;


        }

@Override
public UIAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view= LayoutInflater.from(parent.getContext())
        .inflate(R.layout.instructorui_item,parent,false);
        UIAdapter.ViewHolder viewHolder=new UIAdapter.ViewHolder(view);

        return viewHolder;
        }

@Override
public void onBindViewHolder(UIAdapter.ViewHolder holder,int position){

final Instructor i=list.get(position);
final int tem=position;
        BitmapFactory.Options options=new BitmapFactory.Options();
        options.inJustDecodeBounds=false;
        int photoW=options.outWidth;
        int photoH=options.outHeight;

        // Determine how much to scale down the image
        int scaleFactor=Math.min(photoW/150,photoH/150);
        options.inSampleSize=scaleFactor;
        options.inPurgeable=true;
    if(i.getPicture()!=null) {
        Bitmap image = BitmapFactory.decodeByteArray(i.getPicture(), 0, 120, options);
        holder.pic.setImageBitmap(image);
    }
        holder.pic.setBackground(null);
        holder.name.setText(i.getName());
        holder.email.setText(i.getEmail());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               AddInstructorFragment.edit=true;
               AddInstructorFragment.toEdit=i;
                MainActivity.getF().beginTransaction()
                        .replace(R.id.container, new AddInstructorFragment(), "AddInstructorFragment")
                        .commit();
            }
        });


        }


@Override
public int getItemCount(){
        return list.size();
        }

public static class ViewHolder extends RecyclerView.ViewHolder {
    private ImageView pic;
    private TextView name;
    private TextView email;

    public ViewHolder(View itemView) {
        super(itemView);
        pic = itemView.findViewById(R.id.uiPic);
        name = itemView.findViewById(R.id.uiName);
        email=itemView.findViewById(R.id.uiEmail);

    }
}

    }



