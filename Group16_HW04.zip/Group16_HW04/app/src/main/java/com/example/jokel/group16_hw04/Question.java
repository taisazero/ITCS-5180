package com.example.jokel.group16_hw04;

import android.graphics.Bitmap;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */

public class Question {

    public static ArrayList<Question> questions = new ArrayList<>();
    public final int id;
    public static int ID = 0;
    public Bitmap questionsImage;
    public String description;
    public ArrayList<String> answers;
    public ArrayList<Boolean> corrects;
    private static String JSON = "";
    private String imgURL;



    public Question() {
        questionsImage = null;
        id = ID++;
        answers = new ArrayList<>();
        corrects = new ArrayList<>();
        imgURL = "";
        Log.d("Test j", "Was called");

        Log.d("Test b", "Was called");
    }

    public static void generateQuestions() throws JSONException {

        /*Question question = new Question();
        String[][] testFields;
        testFields = new String[][]{
                {"bird", "to do", "work", "mother", "dad", "brother", "is are"},
                {"xiao", "zuo", "gong zuo", "mama", "baba", "gege", "shi"}};

        Random random = new Random();
        int j = 0;
        question.setDescription(testFields[j][random.nextInt(testFields[j++].length)]);
        for (int i = 0; i < random.nextInt(testFields[j].length-1)+1; i++) {
            question.answers.add(testFields[j][random.nextInt(testFields[j].length)]);
        }
        for (int i = 0; i < question.answers.size(); i++) {
            question.correct.add(random.nextInt(2) < 1);
        }
        return question;*/


        JSONObject o = new JSONObject(JSON);
        Log.d("Step 1", o.toString());
        JSONArray qs = o.getJSONArray("questions");
        Log.d("Step 2", qs.toString());
        for (int i = 0; i < qs.length(); i++) {
            JSONObject qObject = qs.getJSONObject(i);
            Question q = new Question();
            if(qObject.has("image")){
            Log.d("Tracking 2", new Integer(i).toString()+" "+new Boolean(qObject.has("image")).toString());
            q.setImgURL(qObject.getString("image"));
            Log.d("Tracking 3",q.getImgURL());
            }
            else{
                q.setImgURL("");
            }
            Log.d("Step 3", qObject.toString());
            q.setDescription(qObject.getString("text"));
            JSONObject temp = qObject.getJSONObject("choices");
            JSONArray temp2=temp.getJSONArray("choice");
            Log.d("Length",new Integer(temp2.length()).toString());
            ArrayList<String> choices = new ArrayList<String>();
            String correct = temp.getString("answer");
            Integer c = new Integer(correct);
            ArrayList<Boolean> answer = new ArrayList<Boolean>();
            for (int z = 0; z < temp2.length(); z++) {
                choices.add(temp2.getString(z));
                Log.d("Array",temp2.getString(z)+" "+new Integer(z));

                if (z != (c-1))
                    answer.add( false);
                else {
                    answer.add(true);
                }
            }
            q.setAnswers(choices);


                try {
                    q.setCorrect(answer);
                }
                catch(Exception e){
                    e.printStackTrace();
                    Log.d("Array",e.getMessage());
                }
            questions.add(q);
            Log.d("Testing 2", new Integer(questions.size()).toString());
        }


    }

    @Override
    public String toString() {
        return "Question{" +
                "questionsImage=" + questionsImage +
                ", description='" + description + '\'' +
                ", answers=" + answers +
                ", correct=" + corrects +
                '}';
    }

    public static int getTotalNumberCorrect() {
        int num = 0;
        for (Question q : questions) {
            for (Boolean b : q.corrects) {
                if (b) {
                    num++;
                }
            }
        }
        return num;
    }

    public int getId() {
        return id;
    }

    public ArrayList<String> getAnswers() {
        return answers;
    }

    public void setAnswers(ArrayList<String> answers) {
        this.answers = answers;
    }

    public ArrayList<Boolean> getCorrect() {
        return corrects;
    }

    public void setCorrect(ArrayList<Boolean> correct) throws Exception {

        if (corrects.size() > answers.size()) {
           throw new Exception("setCorrect: The correct arraylist is larger \nthan the answer" +
                    " arraylist. This does not make sense.");
        }

        this.corrects = correct;
    }

    public Bitmap getQuestionsImage() {
        return questionsImage;
    }

    public void setQuestionsImage(Bitmap questionsImage) {
        this.questionsImage = questionsImage;
    }

    public String getDescription() {
        return description;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String s) {
        imgURL = s;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setJSON(String s) {
        this.JSON = s;
        Log.d("Testing",JSON);

    }
}



