package com.example.jokel.inclass05_group16;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 1.0 9/25/2017
 *
 */
@SuppressWarnings("unused")
public class Recipe {

    // Static fields for static access
    private static ArrayList<Recipe> recipes;
    private static ArrayList<String> searchIngredients;
    private static String searchName;
    // Fields for instantiated access
    private String ingredients;
    private String name;
    private String href;
    private String thumbnailURL;
    private Bitmap thumbnail;

    public Recipe() {

    }

    public Recipe(String ingredients, String name, String href, String thumbnailURL,
                  Bitmap thumbnail) {
        this.ingredients = ingredients;
        this.name = name;
        this.href = href;
        this.thumbnailURL = thumbnailURL;
        this.thumbnail = thumbnail;
    }

    public static void setRecipes(String s) {
        try {
            JSONObject jsonObject = new JSONObject(s);
            Log.d("Recipe:", "setRecipes:" + jsonObject.toString());
            JSONArray recipesJSONArray = jsonObject.getJSONArray("results");

            for (int i = 0; i < recipesJSONArray.length(); i++) {
                JSONObject recipeJSON = recipesJSONArray.getJSONObject(i);
                Recipe recipe = new Recipe();
                Log.d("Recipe:", "setRecipes:setName" + recipeJSON.getString("title"));
                recipe.setName(recipeJSON.getString("title"));
                Log.d("Recipe:", "setRecipes:setHref" + recipeJSON.getString("href"));
                recipe.setHref(recipeJSON.getString("href"));
                Log.d("Recipe:", "setRecipes:setIngredients" + recipeJSON.getString("ingredients"));
                recipe.setIngredients(recipeJSON.getString("ingredients"));
                Log.d("Recipe:", "setRecipes:setThumbnailURL" + recipeJSON.getString("thumbnail"));
                recipe.setThumbnailURL(recipeJSON.getString("thumbnail"));
                Log.d("Recipe:", "setRecipes:setThumbnail");
                recipe.setThumbnail(recipe.thumbnailURL);
                Log.d("Recipe:", "setRecipes:addRecipe");
                Recipe.addRecipe(recipe);//hi

            }
            //jsonArray

        } catch (JSONException e) {
            Log.d("Recipe:", "setRecipes:failed");
            e.printStackTrace();//hi
        }


    }

    public void removeAllRecipes() {
        recipes = new ArrayList<>();
    }

    public static ArrayList<Recipe> getRecipes() {
        if (Recipe.searchIngredients == null) {
            Recipe.searchIngredients = new ArrayList<>();
        }

        return recipes;
    }

    public static void addRecipe(Recipe recipe) {
        if (Recipe.recipes == null) {
            Recipe.recipes = new ArrayList<>();
        }
        recipes.add(recipe);
    }

    public static ArrayList<String> getSearchIngredients() {
        if (Recipe.searchIngredients == null) {
            Recipe.searchIngredients = new ArrayList<>();
        }

        return searchIngredients;
    }

    public static void setSearchIngredients(ArrayList<String> searchIngredients) {
        if (Recipe.searchIngredients == null) {
            Recipe.searchIngredients = new ArrayList<>();
        }

        Recipe.searchIngredients = searchIngredients;
    }

    public static String getSearchName() {
        return searchName;
    }

    public static void setSearchName(String searchName) {
        Recipe.searchName = searchName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public String getThumbnailURL() {
        return thumbnailURL;
    }

    public void setThumbnailURL(String thumbnailURL) {
        this.thumbnailURL = thumbnailURL;
    }

    public Bitmap getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        URL url = null;
        Bitmap image = null;
        try {
            Log.d("Recipe:","setThumbnail:" + thumbnailURL);
            url = new URL(thumbnailURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET"); // or POST

            image = BitmapFactory.decodeStream(con.getInputStream());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        this.thumbnail = image;
    }
}
