package com.example.jokel.inclass05_group16;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutCompat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import java.lang.reflect.Array;
import java.util.ArrayList;

import java.util.ArrayList;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 1.0 9/25/2017
 *
 */
public class MainActivity extends AppCompatActivity {

    public static final int ACTIVITY_SEARCH = 0;


    ArrayList<View> views=new ArrayList<View>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       LinearLayout parentLayout=(LinearLayout)findViewById(R.id.parent) ;
        parentLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout container= new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        IngredientItem ingredient1=new IngredientItem(this);


        View v= (View)ingredient1;

        container.addView(v);//hi
        ingredient1.add.setScaleX(ingredient1.add.getScaleY());

        parentLayout.addView(container);





      createButtonHandlers();


    }

    public void createButtonHandlers() {

        Button btn1 = (Button) findViewById(R.id.btnSearch);//hi
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ProgressActivity.class);
                intent.putExtra("ID", MainActivity.ACTIVITY_SEARCH);
                Recipe.setSearchName("omelette");
                EditText t1= (EditText)(MainActivity.this.findViewById(R.id.dishName)) ;
                Recipe.setSearchName(t1.getText().toString());
                ArrayList<String> ingredients = new ArrayList<String>();
                for (View v: views){
                    EditText t=(EditText)(findViewById(R.id.ingredient));
                   ingredients.add(t.getText().toString());
                }
                ingredients.add("onions");
                ingredients.add("garlic");
                Recipe.setSearchIngredients(ingredients);
                startActivity(intent);
            }
        });
        switch(views.size()) {

            case 0:
            ImageButton addRemove = (ImageButton) findViewById(R.id.add);

            addRemove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (views.size() != 4) {
                        ImageButton addRemove = (ImageButton) findViewById(R.id.add);
                        ImageButton remove=(ImageButton)findViewById(R.id.remove);
                        remove.setVisibility(View.VISIBLE);
                        addRemove.setVisibility(View.INVISIBLE);


                        IngredientItem i = new IngredientItem(MainActivity.this);
                        View v = (View) i;

                        LinearLayout container = new LinearLayout(MainActivity.this);
                        LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                        container.addView(v);
                        parentLayout.addView(container);
                        views.add(v);



                    }
                }
            });
                ImageButton r0 = (ImageButton) this.findViewById(R.id.remove);

                r0.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (views.size() != 4) {
                            ImageButton add = (ImageButton) findViewById(R.id.add);
                            ImageButton remove=(ImageButton)findViewById(R.id.remove);
                            remove.setVisibility(View.INVISIBLE);
                            add.setVisibility(View.VISIBLE);

                            LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                            parentLayout.removeView(views.get(0));




                        }
                    }
                });
                break;
            case 1:

                ImageButton b = (ImageButton)views.get(0).findViewById(R.id.add);

                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (views.size() != 4) {
                            ImageButton addRemove = (ImageButton) view.findViewById(R.id.add);
                            ImageButton remove=(ImageButton)view.findViewById(R.id.remove);
                            remove.setVisibility(View.VISIBLE);
                            addRemove.setVisibility(View.INVISIBLE);


                            IngredientItem i = new IngredientItem(MainActivity.this);
                            View v = (View) i;

                            LinearLayout container = new LinearLayout(MainActivity.this);
                            LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                            container.addView(v);
                            parentLayout.addView(container);
                            views.add(v);



                        }
                    }
                });

            ImageButton r1 = (ImageButton) this.findViewById(R.id.remove);
            r1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (views.size() != 4) {
                        ImageButton add = (ImageButton) findViewById(R.id.add);
                        ImageButton remove=(ImageButton)findViewById(R.id.remove);
                        remove.setVisibility(View.INVISIBLE);
                        add.setVisibility(View.VISIBLE);

                        LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                        parentLayout.removeView(views.get(1));




                    }
                }
            });
            break;
            case 2:
                ImageButton b1 = (ImageButton)views.get(1).findViewById(R.id.add);

                b1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (views.size() != 4) {
                            ImageButton addRemove = (ImageButton) view.findViewById(R.id.add);
                            ImageButton remove=(ImageButton)view.findViewById(R.id.remove);
                            remove.setVisibility(View.VISIBLE);
                            addRemove.setVisibility(View.INVISIBLE);


                            IngredientItem i = new IngredientItem(MainActivity.this);
                            View v = (View) i;

                            LinearLayout container = new LinearLayout(MainActivity.this);
                            LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                            container.addView(v);
                            parentLayout.addView(container);
                            views.add(v);



                        }
                    }
                });

            ImageButton r2 = (ImageButton) this.findViewById(R.id.remove);
            r2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (views.size() != 4) {
                        ImageButton add = (ImageButton) findViewById(R.id.add);
                        ImageButton remove=(ImageButton)findViewById(R.id.remove);
                        remove.setVisibility(View.INVISIBLE);
                        add.setVisibility(View.VISIBLE);

                        LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                        parentLayout.removeView(views.get(2));




                    }
                }
            });
                break;
            case 3:

                ImageButton b2 = (ImageButton)views.get(2).findViewById(R.id.add);

                b2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (views.size() != 4) {
                            ImageButton addRemove = (ImageButton) view.findViewById(R.id.add);
                            ImageButton remove=(ImageButton)view.findViewById(R.id.remove);
                            remove.setVisibility(View.VISIBLE);
                            addRemove.setVisibility(View.INVISIBLE);


                            IngredientItem i = new IngredientItem(MainActivity.this);
                            View v = (View) i;

                            LinearLayout container = new LinearLayout(MainActivity.this);
                            LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                            container.addView(v);
                            parentLayout.addView(container);
                            views.add(v);



                        }
                    }
                });
                ImageButton r3 = (ImageButton) this.findViewById(R.id.remove);
                r3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (views.size() != 4) {
                            ImageButton add = (ImageButton) findViewById(R.id.add);
                            ImageButton remove=(ImageButton)findViewById(R.id.remove);
                            remove.setVisibility(View.INVISIBLE);
                            add.setVisibility(View.VISIBLE);

                            LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                            parentLayout.removeView(views.get(3));




                        }
                    }
                });
                break;

            case 4:

                ImageButton b3 = (ImageButton)views.get(3).findViewById(R.id.add);

                b3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (views.size() != 4) {
                            ImageButton addRemove = (ImageButton) view.findViewById(R.id.add);
                            ImageButton remove=(ImageButton)view.findViewById(R.id.remove);
                            remove.setVisibility(View.VISIBLE);
                            addRemove.setVisibility(View.INVISIBLE);


                            IngredientItem i = new IngredientItem(MainActivity.this);
                            View v = (View) i;

                            LinearLayout container = new LinearLayout(MainActivity.this);
                            LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                            container.addView(v);
                            parentLayout.addView(container);
                            views.add(v);



                        }
                    }
                });
                ImageButton r4 = (ImageButton) this.findViewById(R.id.remove);
                r4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (views.size() != 4) {
                            ImageButton add = (ImageButton) findViewById(R.id.add);
                            ImageButton remove=(ImageButton)findViewById(R.id.remove);
                            remove.setVisibility(View.INVISIBLE);
                            add.setVisibility(View.VISIBLE);

                            LinearLayout parentLayout = (LinearLayout) findViewById(R.id.parent);
                            parentLayout.removeView(views.get(4));




                        }
                    }
                });

                break;
            default:
                System.out.println("HI I was very lonely");
        }
    }






    private boolean isConnectionOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();

        // networkInfo.getType(); can be used to determine to to download

        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }

        return false;
    }
}
