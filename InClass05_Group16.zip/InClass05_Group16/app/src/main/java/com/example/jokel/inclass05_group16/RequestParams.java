package com.example.jokel.inclass05_group16;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

/**
 * Created by jokel on 9/25/2017.
 */

public class RequestParams {
    String method, baseURL;
    HashMap<String,String> params = new HashMap<>();

    public RequestParams(String method, String baseURL) {
        this.method = method;
        this.baseURL = baseURL;
    }

    public void addParam(String key, String value) {
        params.put(key, value);
    }

    public String getEncodedParams() {
        // loop over the key/value pairs of the params
        // append to a stringbuild key=value
        // figure out how to add the &

        StringBuilder stringBuilder = new StringBuilder();
        for (String key:params.keySet()) {
            try {
                String value = URLEncoder.encode(params.get(key), "UTF-8");
                if(stringBuilder.length() > 0) {
                    stringBuilder.append("&");
                }
                stringBuilder.append(key + "=" + value);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        }

        return stringBuilder.toString();
    }

    public String getEncodedURL() {
        return this.baseURL + "?" + getEncodedParams();
    }

    public HttpURLConnection setupConnection() throws IOException {

        if (method.equals("GET")) {

            URL url = new URL(getEncodedURL());
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET"); // or POST

            return con;
        } else { // Post case
            URL url = new URL(this.baseURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST"); // or POST
            con.setDoOutput(true);
            OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream());
            writer.write(getEncodedParams());
            writer.flush();
            return con;
        }
    }
}
