package com.example.jokel.group16_hw04;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */

public class GetTextFromURL extends AsyncTask<String,Integer,String> {
    Question q;
    ProgressBar pb;
    Button next;
    ImageView pic;
    public GetTextFromURL(Question q, ProgressBar pb, Button next, ImageView pic){
        this.pb=pb;
        this.q=q;
        this.next=next;
        this.pic=pic;
    }

    @Override
    protected void onPreExecute(){
        pb.setVisibility(View.VISIBLE);
        pb.setProgress(0);
        pb.setMax(229);

    }
    @Override
    protected void onProgressUpdate(Integer...values){
        pb.setProgress(values[0]);

    }
    @Override
    protected String doInBackground(String... params) {
        try{
            StringBuilder s =new StringBuilder();
            URL link=new URL(params[0]);
            HttpURLConnection connection=(HttpURLConnection)link.openConnection();
            connection.setRequestMethod("GET");
            BufferedReader reader= new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line="";
            int i=0;
            while ((line=reader.readLine())!=null){
                s.append(line+ "\n");
                publishProgress(i+1);
                try {
                    Thread z=new Thread();
                    z.sleep(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            reader.close();
            return s.toString();

        }catch(Exception e){
            e.printStackTrace();
        }
        return null;



    }

    @Override
    protected void onPostExecute(String s ){
        Log.d("Importing Questions",s);
        next.setEnabled(true);
        q.setJSON(s);

        next.setClickable(true);
        pb.setVisibility(View.INVISIBLE);
        pic.setVisibility(View.VISIBLE);

        try {
            Question.generateQuestions();
        } catch (JSONException e) {

            e.printStackTrace();
        }


        Log.d("JSON set","true");

    }


}
