package com.example.jokel.inclass05_group16;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 1.0 9/25/2017
 *
 */
public class RecipePuppyHandler extends AsyncTask<RequestParams, Integer, String>{

    private AppCompatActivity context;
    private ProgressBar progressBar;
    private TextView progressText;
    private int progress;
    private BufferedReader br;

    public void setContext(AppCompatActivity context) {
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        progressBar = (ProgressBar) context.findViewById(R.id.barProgressBar);
        progressText = (TextView) context.findViewById(R.id.txtProgress);
        progressText.setText("Starting...");
        progressBar.setMax(8);
        progressBar.setProgress(0);
        progressBar.setVisibility(ProgressBar.VISIBLE);
        progress = 1;
    }

    @Override
    protected String doInBackground(RequestParams... params) {
        Log.d("RecipePuppyHandler:", "doInBackground:with:" + params[0]);
        publishProgress(progress++);
        URL url = null;
        try {
            // Set the url
            HttpURLConnection con = params[0].setupConnection();
            con.setRequestMethod("GET"); // or POST
            publishProgress(progress++);
            // Read the results
            br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = "";
            publishProgress(progress++);
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
            publishProgress(progress++);

            publishProgress(progress++);
            Log.d("RecipePuppyHandler:", "doInBackground:setRecipes:" + sb.toString());
            Recipe.setRecipes(sb.toString());
            publishProgress(progress++);
            Log.d("RecipePuppyHandler:", "doInBackground:return:");
            return sb.toString();

        } catch (IOException e) {
            Log.d("RecipePuppyHandler:", "doInBackground:failed:");
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        progressText.setText("Finished...");
        progressBar.setProgress(8);
        Log.d("RecipePuppyHandler:", "onPostExecute:" + s);

        Intent intent = new Intent(context, RecipiesActivity.class);
        context.startActivity(intent);
        context.finish();
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        Log.d("RecipePuppyHandler:", "onProgressUpdate:" + values[0]);
        if (progressBar.getProgress() == 0) {
            progressText.setText("Loading...");
        } else {
            progressBar.setProgress(values[0]);
            progressBar.refreshDrawableState();
        }
    }
}
