package com.example.jokel.hw06.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.jokel.hw06.MainActivity;
import com.example.jokel.hw06.R;
import com.example.jokel.hw06.adapters.CourseAdapter;
import com.example.jokel.hw06.db.Course;
import com.example.jokel.hw06.db.User;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;


public class CourseManagerFragment extends Fragment {

    private LinearLayoutManager mLayoutManager;
    private OnFragmentInteractionListener mListener;
    private String chosenCourse="";
    private RecyclerView rv;
    public static String user;

    public String getChosenCourse() {
        return chosenCourse;
    }

    public void setChosenCourse(String chosenCourse) {
        this.chosenCourse = chosenCourse;
    }

    public static boolean flagAddCourse = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_course_manager, container, false);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.gotoNextFragment();
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rv=getView().findViewById(R.id.listCourses);
        Realm realm= Realm.getDefaultInstance();
        RealmResults<Course> courses = realm.where(Course.class)
                .equalTo("username",user).findAll();
        CourseAdapter adapter= new CourseAdapter(courses,this);
        rv.setLayoutManager(mLayoutManager);
        rv.setAdapter(adapter);
        //rv.notify();


        ImageButton btnAddCourses = getView().findViewById(R.id.btnAddCourse);
        btnAddCourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagAddCourse = true;
                mListener.gotoNextFragment();
            }
        });

    }




    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    public void updateAdapter(){

        Realm realm= Realm.getDefaultInstance();
        RealmResults<Course> courses = realm.where(Course.class).findAll();
        CourseAdapter adapter= new CourseAdapter(courses,this);
        adapter.notifyDataSetChanged();
        rv.setLayoutManager(mLayoutManager);
        rv.setAdapter(adapter);
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void gotoNextFragment();
    }
}
