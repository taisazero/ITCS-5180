package com.example.jokel.hw06.adapters;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jokel.hw06.R;
import com.example.jokel.hw06.db.Course;
import com.example.jokel.hw06.db.User;
import com.example.jokel.hw06.fragments.CourseManagerFragment;
import com.example.jokel.hw06.fragments.CreateCourseFragment;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;

/**
 * Created by Zero on 11/8/2017.
 */

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.ViewHolder> {

    RealmResults<Course> list;
    CourseManagerFragment c;

    public CourseAdapter(RealmResults<Course> list, CourseManagerFragment c) {
        this.list = list;
        this.c = c;
    }

    @Override
    public CourseAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.course_item,parent,false);
        CourseAdapter.ViewHolder viewHolder= new CourseAdapter.ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CourseAdapter.ViewHolder holder, final int position) {
        final Course s= list.get(position);
        BitmapFactory.Options options= new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        int photoW = options.outWidth;
        int photoH = options.outHeight;

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW/150, photoH/150);
        options.inSampleSize = scaleFactor;
        options.inPurgeable = true;
        if(s.getInstructor().getPicture()!=null) {
            Bitmap image = BitmapFactory.decodeByteArray(s.getInstructor().getPicture(), 0, 120, options);
            holder.pic.setImageBitmap(image);
        }
        holder.title.setText(s.getTitle());
        holder.time.setText(s.getDay()+ " "+s.getHour()+":"+s.getMinutes()+" "+s.getAmpm());
        holder.iNameC.setText(s.getInstructor().getName());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c.setChosenCourse(s.getTitle());
            }

        });
       holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
           @Override
           public boolean onLongClick(View view) {

               AlertDialog.Builder alertDialog=new AlertDialog.Builder(c.getContext());
               alertDialog.setTitle("Are you sure you want to delete the course?");
               alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, int i) {
                        Realm realm = realm = Realm.getDefaultInstance();
                       try {
                           realm.executeTransaction(new Realm.Transaction() {
                               @Override
                               public void execute(Realm realm) {
                                   list.deleteFromRealm(position);
                               }
                           });

                       } finally {
                           realm.close();

                       }

                       c.updateAdapter();


                   }
               });
               alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, int i) {
                       Log.d("Alert","Clicked Cancel");

                   }
               });
               final AlertDialog alert= alertDialog.create();
               alert.show();


               return false;
           }
       });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView pic;
        private TextView title;
        private TextView time;
        private TextView iNameC;
        public ViewHolder(View itemView) {
            super(itemView);
            pic=itemView.findViewById(R.id.coursePic);
            title=itemView.findViewById(R.id.title);
            time=itemView.findViewById(R.id.cTime);
            iNameC=itemView.findViewById(R.id.iNameC);
        }

    }
}
