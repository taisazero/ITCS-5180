package com.example.jokel.hw06.adapters;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jokel.hw06.MainActivity;
import com.example.jokel.hw06.R;
import com.example.jokel.hw06.db.ImageSaver;
import com.example.jokel.hw06.db.Instructor;
import com.example.jokel.hw06.fragments.CreateCourseFragment;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import io.realm.RealmResults;

/**
 * Created by Zero on 11/8/2017.
 */

public class InstructorAdapter extends RecyclerView.Adapter<InstructorAdapter.ViewHolder> {

    RealmResults<Instructor> list;
    CreateCourseFragment c;
    static ArrayList<RadioButton>rList=new ArrayList<RadioButton>();

    public InstructorAdapter(RealmResults<Instructor> list, CreateCourseFragment c ) {
        this.list = list;
        this.c=c;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.instructor_item,parent,false);
       InstructorAdapter.ViewHolder viewHolder= new InstructorAdapter.ViewHolder(view);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Instructor i = list.get(position);
        final int tem=position;
       BitmapFactory.Options options= new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        int photoW = options.outWidth;
        int photoH = options.outHeight;

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW/150, photoH/150);
        options.inSampleSize = scaleFactor;
       options.inPurgeable = true;
       if(i.getPicture()!=null) {
           Bitmap image = BitmapFactory.decodeByteArray(i.getPicture(), 0, 120, options);

           holder.pic.setImageBitmap(image);
       }
        holder.pic.setBackground(null);
     // holder.pic.setImageBitmap(ImageSaver.loadImage( c.getActivity(),i.getfName()+i.getlName()));
        holder.name.setText(i.getName());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                c.setChosenI(i.getName());//hi
                if(holder.rb.isChecked()) {
                    holder.rb.setChecked(false);
                }
                else {
                    for (RadioButton r: rList){
                        r.setChecked(false);
                    }
                    holder.rb.setChecked(true);


                    Toast.makeText(c.getActivity(),i.getName()+" is chosen!",Toast.LENGTH_LONG).show();
                }


            }
        });
        holder.rb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c.setChosenI(i.getName());//hi
                if(holder.rb.isChecked()) {
                    holder.rb.setChecked(false);
                }
                else {
                    for (RadioButton r: rList){
                        r.setChecked(false);
                    }
                    holder.rb.setChecked(true);


                    Toast.makeText(c.getActivity(),i.getName()+" is chosen!",Toast.LENGTH_LONG).show();
                }

            }
        });



    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        private ImageView pic;
        private TextView name;
        private RadioButton rb;
        public ViewHolder(View itemView) {
            super(itemView);
            pic=itemView.findViewById(R.id.instructPic);
            name=itemView.findViewById(R.id.iName);
            rb=itemView.findViewById(R.id.rButton);

            rList.add(rb);


        }
    }
}
