package com.example.zero.inclass13;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "Main";
    public static ArrayList<Trip> listOfTrips=new ArrayList<Trip>();
    public static ArrayList<Place> placeList=new ArrayList<Place>();
    FirebaseDatabase db= FirebaseDatabase.getInstance();
    DatabaseReference myDb=db.getReference("Deals");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        RecyclerView tripList=findViewById(R.id.tripListMain);
        Spinner sp = findViewById(R.id.spinner);

        readFromDB();
        setHandlers();



    }

    public void setHandlers(){
        final ImageButton addTrip=findViewById(R.id.mainAddTrip);
        addTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,createTrip.class);
                startActivity(i);
                //finish();
            }
        });
    }

    public void readFromDB(){
        String temp= myDb.push().getKey();
        myDb.child(temp).setValue("Test");
        myDb.child(temp).removeValue();
        // Read from the database
        myDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Place trip= new Place();
                for (DataSnapshot d : dataSnapshot.getChildren()) {
                    int i=0;

                    for (DataSnapshot s : d.getChildren()) {

                        if (i == 1 || i == 3) {
                            String z = s.getValue(String.class);
                            Log.d("VALUES2!", z);
                            if(i==1){
                                trip.setDuration(z);
                            }
                            else if(i==3){
                                trip.setPlace(z);
                            }

                            // list.add(value);
                            // Log.d("VALUES!", value.toString());
                        }
                        else if (i==0){
                            Double cost=s.getValue(Double.class);
                            trip.setCost(cost);

                        }
                        else if (i==2){
                            int locTemp=0;
                            for (DataSnapshot l : s.getChildren()){
                                if(locTemp==0){
                                Double lat=l.getValue(Double.class);
                                trip.setLat(lat);
                                }
                                else if (locTemp==1){
                                    Double lon = l.getValue(Double.class);
                                    trip.setLon(lon);

                                }
                                locTemp++;
                            }
                        }

                        i++;
                    }
                    placeList.add(trip);

                }
                Log.d(TAG,placeList.toString());
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
        String temp2= myDb.push().getKey();
        myDb.child(temp2).setValue("Test2");
        myDb.child(temp2).removeValue();
    }
}
