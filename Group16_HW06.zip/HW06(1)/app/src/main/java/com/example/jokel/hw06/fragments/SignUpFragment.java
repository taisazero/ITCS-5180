package com.example.jokel.hw06.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.app.Fragment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.jokel.hw06.MainActivity;
import com.example.jokel.hw06.R;
import com.example.jokel.hw06.db.ImageSaver;
import com.example.jokel.hw06.db.User;

import java.io.ByteArrayOutputStream;

import io.realm.Realm;
import io.realm.RealmResults;

import static android.app.Activity.RESULT_OK;

public class SignUpFragment extends Fragment {
    private static final int CAMERA_CODE = 1 ;
    public static ImageButton pic ;
    public static Button btnSignUp;
    public static EditText editFirstName;
    public static EditText editLastName;
    public static EditText password;
    public static EditText userNameSignUp;
    public static byte[] byteArray;
    public static Bitmap picture;
    public static boolean done = false;
    private SignUpFragment.OnFragmentInteractionListener mListener;
    LinearLayoutManager mLayoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sign_up, container, false);

    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLayoutManager = new LinearLayoutManager(getActivity(),LinearLayoutManager.VERTICAL,false);

        pic = getView().findViewById(R.id.btnProfilePic);
        btnSignUp = getView().findViewById(R.id.btnSignup);
        userNameSignUp = getView().findViewById(R.id.editSignUpU);
        password = getView().findViewById(R.id.editPassword2);
        editFirstName=getView().findViewById(R.id.editFirstName);
        editLastName=getView().findViewById(R.id.editLastName);



        pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (i.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivityForResult(i, CAMERA_CODE);
                }
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                boolean ready = (!userNameSignUp.getText().toString().equals(""))&&(!password.getText().toString().equals(""))&&(!editLastName.getText().toString().equals(""))&&(!editFirstName.getText().toString().equals(""));
                boolean validPass = password.getText().toString().length()>=8;
                String pass=userNameSignUp.getText().toString();

                Realm realm = Realm.getDefaultInstance();


                    RealmResults<User> users = realm.where(User.class)
                            .equalTo("username", userNameSignUp.getText().toString())
                            .findAll();


                    if (users.size() != 0) {
                        Toast.makeText(getActivity(),"This Account Already Exists!",Toast.LENGTH_LONG).show();
                        ready=false;
                    }



                if(ready && validPass ){
                    done=true;
                    mListener.gotoNextFragment();
                }
                else if (!validPass){
                    Toast.makeText(getActivity(),"Invalid Password!",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getActivity(),"One of the fields is not filled!",Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == CAMERA_CODE) {
                Bitmap image = (Bitmap) data.getExtras().get("data");//from Camera
                image = image.createScaledBitmap(image, 750, 750, false);
                pic.setImageBitmap(image);
             //   ImageSaver.saveImage(userNameSignUp.getText().toString(),image,(MainActivity) (getActivity()));



                if (image != null) {
                    picture=image;
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    image.compress(Bitmap.CompressFormat.PNG, 10, stream);
                    byteArray = stream.toByteArray();


                }

            }
        }
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void gotoNextFragment();
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof LoginFragment.OnFragmentInteractionListener) {
            mListener = (SignUpFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}
