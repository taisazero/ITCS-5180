package com.example.jokel.hw06.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.app.Fragment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.jokel.hw06.InstructorUI;
import com.example.jokel.hw06.MainActivity;
import com.example.jokel.hw06.R;
import com.example.jokel.hw06.adapters.UIAdapter;
import com.example.jokel.hw06.db.ImageSaver;
import com.example.jokel.hw06.db.Instructor;

import java.io.ByteArrayOutputStream;

import io.realm.Realm;
import io.realm.RealmResults;

import static android.app.Activity.RESULT_OK;

public class AddInstructorFragment extends Fragment {
    private static final int CAMERA_CODE = 1 ;
    public static ImageButton pic ;
    public static Button btnAdd;
    public static Button reset;
    public static EditText editFirstName;
    public static EditText editLastName;
    public static EditText editWebsite;
    public static EditText editEmail;
    public static byte[] byteArray;
    public static boolean done = false;
    public static boolean edit=false;
    public static Instructor toEdit;
    public static Bitmap picture;
    private SignUpFragment.OnFragmentInteractionListener mListener;
    LinearLayoutManager mLayoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_instructor, container, false);

    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLayoutManager = new LinearLayoutManager(getActivity(),LinearLayoutManager.VERTICAL,false);

        pic = getView().findViewById(R.id.btnProfilePic);
        btnAdd = getView().findViewById(R.id.btnAdd);
        editEmail = getView().findViewById(R.id.editEmail);
        editWebsite = getView().findViewById(R.id.editWebsite);
        editFirstName=getView().findViewById(R.id.editFirstName);
        editLastName=getView().findViewById(R.id.editLastName);
        if(edit){
            BitmapFactory.Options options=new BitmapFactory.Options();
            Bitmap image =BitmapFactory.decodeByteArray(toEdit.getPicture(),0, 120, options);
            image.createScaledBitmap(image, 150, 150, false);
            pic.setImageBitmap(image);
            editEmail.setText(toEdit.getEmail());
            editWebsite.setText(toEdit.getUrl());
            editFirstName.setText(toEdit.getfName());
            editLastName.setText(toEdit.getlName());
            editFirstName.setEnabled(false);
            editLastName.setEnabled(false);

        }


        reset = getView().findViewById(R.id.btnReset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editEmail.setText("");
                editFirstName.setText("");
                editLastName.setText("");
                editWebsite.setText("");
            }
        });

        pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (i.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivityForResult(i, CAMERA_CODE);
                }
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                boolean ready = (!
                        editEmail.getText().toString().equals(""))&&
                        (!editWebsite.getText().toString().equals(""))
                        &&(!editLastName.getText().toString().equals(""))
                        &&(!editFirstName.getText().toString().equals("")&&
                        (!editWebsite.getText().toString().equals("")));
                String pass= editEmail.getText().toString();
                Realm realm= Realm.getDefaultInstance();
                RealmResults<Instructor> instructor=realm.where(Instructor.class)
                        .equalTo("name",editFirstName.getText().toString()+" "+editLastName.getText().toString())
                        .findAll();
                if(instructor.size()!=0 &&edit==false){
                    Toast.makeText(getActivity(),"This instructor Already Exists!",Toast.LENGTH_LONG).show();
                    ready=false;
                }

                Log.d("SignUpFragment", "onClick:" + editEmail.getText().toString());
                Log.d("Password", pass);
                Log.d("Password",new Integer(pass.length()).toString());
                if(ready && edit==false){
                    done=true;
                    mListener.gotoNextFragment();

                }
                else if (edit){

                    Realm realm2= Realm.getDefaultInstance();
                    RealmResults<Instructor> instructor2=realm2.where(Instructor.class)
                            .equalTo("name",editFirstName.getText().toString()+" "+editLastName.getText().toString())
                            .findAll();
                   Instructor user= instructor2.first();
                    realm2.beginTransaction();
                    user.setfName(editFirstName.getText().toString());
                    user.setlName(editLastName.getText().toString());

                    user.setEmail(editEmail.getText().toString());
                    user.setUrl(editWebsite.getText().toString());
                   realm2.copyToRealmOrUpdate(user);
                   realm2.commitTransaction();
                    mListener.gotoNextFragment();


                }
                else{
                    Toast.makeText(getActivity(),"One of the fields is not filled!",Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == CAMERA_CODE) {
                Bitmap image = (Bitmap) data.getExtras().get("data");//from Camera
                image = image.createScaledBitmap(image, 750, 750, false);
                pic.setImageBitmap(image);
                //ImageSaver.saveImage(editFirstName.getText().toString()+editLastName.getText().toString(),image, getActivity());


                    picture=image;
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    image.compress(Bitmap.CompressFormat.PNG, 10, stream);
                    byteArray = stream.toByteArray();





            }
        }
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void gotoNextFragment();
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof LoginFragment.OnFragmentInteractionListener) {
            mListener = (SignUpFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}
