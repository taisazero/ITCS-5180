package com.example.jokel.hw06.db;

import android.graphics.Bitmap;

import io.realm.RealmObject;
import io.realm.annotations.Index;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

/**
 * @author Josiah Laivins
 * @version 10/23/2017
 */

public class User extends RealmObject {


    @Index
    private long id;
    @PrimaryKey
    private String username;
    @Required
    private String password;
    private byte[] picture;
    private String fName;
    private String lName;




    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public byte[] getPicture() {
        return picture;
    }

    public void setPicture(byte[] picture) {
        this.picture = picture;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

   @Override
    public boolean equals(Object obj) {
        User u = (User) obj;
        return this.getUsername().equals(u.getUsername());
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", editWebsite='" + password + '\'' +
                '}';
    }
}
