package com.example.zero.inclass13;

import android.location.Location;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by Zero on 12/4/2017.
 */

public class placeAdapter extends RecyclerView.Adapter<placeAdapter.ViewHolder> {
   static ArrayList<Place> list;
   static ArrayList<CheckBox> checkList;
   private ArrayList<Place> journey=new ArrayList<Place>();
   public static Location CLT= new Location("");



    public placeAdapter(ArrayList<Place> list) {
        this.list = list;
        CLT.setLatitude(35.2271);
        CLT.setLongitude(-80.843124);
    }

    @Override
    public placeAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.place_item,parent,false);
        placeAdapter.ViewHolder viewHolder= new placeAdapter.ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final placeAdapter.ViewHolder holder, final int position) {
        Place place=list.get(position);
        holder.place.setText(place.getPlace());
        holder.cost.setText(holder.cost.getText().toString()+" "+place.getCost());
        holder.duration.setText("("+place.getDuration()+")");
        Location temp= new Location("");
        temp.setLatitude(place.getLat());
        temp.setLongitude(place.getLon());
        double dist= CLT.distanceTo(temp);
        holder.distance.setText(new Double(dist).toString()+" miles away");
        holder.place.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                if(holder.place.isChecked()){
                    holder.place.setChecked(false);
                    journey.remove(list.get(position));
                }
                else if(holder.place.isChecked()==false){
                    holder.place.setChecked(true);
                    journey.add(list.get(position));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private CheckBox place;
        private TextView cost;
        private TextView duration;
        private TextView distance;

        public ViewHolder(View itemView) {
            super(itemView);
            place=itemView.findViewById(R.id.placeCheck);
            cost=itemView.findViewById(R.id.placeCost);
            distance=itemView.findViewById(R.id.distance);
            duration=itemView.findViewById(R.id.estimation);


        }

    }

    public ArrayList<Place> getJourney(){
        return journey;
    }
}
