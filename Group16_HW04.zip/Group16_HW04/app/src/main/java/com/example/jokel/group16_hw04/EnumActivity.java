package com.example.jokel.group16_hw04;

/**
 * Created by jokel on 9/29/2017.
 */

public enum EnumActivity {

    ACTIVTY_NEXT,
    ACTIVTY_START,
    ACTIVTY_EXIT,
    ACTIVITY_STATS;
}
