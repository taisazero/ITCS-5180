package com.example.jokel.hw06.db;

import android.app.Activity;
import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;

import com.example.jokel.hw06.MainActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by Zero on 11/9/2017.
 */

public class ImageSaver {
    public static void saveImage(String fileName,Bitmap pic,Activity mc){
        String path = Environment.getExternalStorageDirectory().toString();
        OutputStream fOut = null;
        Integer counter = 0;
        File file = new File(path, fileName+".jpg");
        try {
            fOut = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Bitmap pictureBitmap = pic;
        pictureBitmap.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
        try {
            fOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            MediaStore.Images.Media.insertImage(mc.getContentResolver(),file.getAbsolutePath(),file.getName(),file.getName());

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Bitmap loadImage(Activity mc,String fileName){
        String path = Environment.getExternalStorageDirectory().toString();
        File file = new File(path, fileName+".jpg");
        Bitmap img=null;
        try {
            img=MediaStore.Images.Media.getBitmap(mc.getContentResolver(), Uri.parse(file.getAbsolutePath()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return img;
    }


}
