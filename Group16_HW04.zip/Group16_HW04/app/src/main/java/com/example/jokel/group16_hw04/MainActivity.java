package com.example.jokel.group16_hw04;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

/**
 * @author Josiah Laivins
 * @author Erfan Al-Hossami
 *
 * @version 10/3/2017
 *
 */
public class MainActivity extends AppCompatActivity{
    ProgressBar pb;
    Button next;
     ImageView pic;

    public Context getContext(){
        return this;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            pb= (ProgressBar)findViewById(R.id.pgbTriviaLoad);
        next=(Button)findViewById(R.id.btnStart);
        next.setClickable(false);
        next.setEnabled(false);
        pic=(ImageView)findViewById(R.id.imgTrivia) ;
        pic.setVisibility(View.INVISIBLE);

            Question q=new Question();
        new GetTextFromURL(q,pb,next,pic).execute("http://dev.theappsdr.com/apis/trivia_json/index.php");
        Thread t=new Thread();






        setButtonHandlers();
    }




    public void setButtonHandlers() {

        Button btnExit = (Button) findViewById(R.id.btnExit);
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Button btnStart = (Button) findViewById(R.id.btnStart);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TriviaActivity.class);
                intent.putExtra("ID", EnumActivity.ACTIVTY_START);
                startActivity(intent);
            }
        });
    }
}
