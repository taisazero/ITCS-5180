package com.example.jokel.hw06.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.jokel.hw06.MainActivity;
import com.example.jokel.hw06.R;
import com.example.jokel.hw06.adapters.CourseAdapter;
import com.example.jokel.hw06.adapters.InstructorAdapter;
import com.example.jokel.hw06.db.Course;
import com.example.jokel.hw06.db.Instructor;
import com.example.jokel.hw06.db.User;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;


public class CreateCourseFragment extends Fragment {


    private LinearLayoutManager mLayoutManager;
    private String chosenI="";
    private static RecyclerView rv;
    public static String loggedUser;


    public String getChosenI() {
        return chosenI;
    }

    public void setChosenI(String chosenI) {
        this.chosenI = chosenI;
    }



    private OnFragmentInteractionListener mListener;

    public static boolean flagCreateCourse = false;
    public User user;
    public String title;
    public String day;
    public int hour;
    public int minutes;
    public String ampm;
    public int creditHours;
    public String semester;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_create_course, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.gotoNextFragment();
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setHandlers();
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        rv = getView().findViewById(R.id.listInstructors);
        Realm realm =Realm.getDefaultInstance();
        RealmResults<Instructor> instructors = realm.where(Instructor.class).findAll();


        InstructorAdapter adapter= new InstructorAdapter(instructors,this);
        rv.setLayoutManager(mLayoutManager);
        rv.setAdapter(adapter);
        //rv.notify();

        Button btnCreate = getView().findViewById(R.id.btnCreate);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagCreateCourse = true;

                EditText editTitle = getView().findViewById(R.id.editTitle);
                Spinner spinDay = (Spinner)(getView().findViewById(R.id.spinPickDay));
                EditText editHour = getView().findViewById(R.id.editHour);
                EditText editMinutes = getView().findViewById(R.id.editMinutes);
                Spinner spinAMPM = getView().findViewById(R.id.spinPickAMPM);
                RadioGroup radioCredit = getView().findViewById(R.id.radioCourseHours);
                Spinner spinSemester = getView().findViewById(R.id.spinSemester);

                //TODO add instructor to a string variable here
                String instructor = getChosenI();

                title = editTitle.getText().toString();
                day = spinDay.getSelectedItem().toString();

                try {

                    hour = Integer.parseInt(editHour.getText().toString());
                    minutes = Integer.parseInt(editMinutes.getText().toString());
                } catch(NumberFormatException e) {
                    Toast.makeText(getActivity(), "Missing fields", Toast.LENGTH_SHORT).show();
                }
                ampm = spinAMPM.getSelectedItem().toString();
                RadioButton r = getView().findViewById(radioCredit.getCheckedRadioButtonId());
                creditHours = Integer.parseInt(r.getText().toString());
                semester = spinSemester.getSelectedItem().toString();

                if (hour > 0 && hour < 13) {
                    if (minutes > 0 && minutes < 60) {

                        Realm realm = Realm.getDefaultInstance();
                        RealmResults<Course> courses2 = realm.where(Course.class).equalTo("title", title).findAll();
                        if (courses2.size() != 0) {
                            Toast.makeText(getActivity(), "This course already exists!", Toast.LENGTH_LONG).show();
                        } else {

                            try {

                                realm.executeTransaction(new Realm.Transaction() {
                                    @Override
                                    public void execute(Realm realm) {
                                        Course course = realm.createObject(Course.class, title);
                                        course.setDay(day);
                                        course.setHour(hour);
                                        course.setMinutes(minutes);
                                        course.setAmpm(ampm);
                                        course.setCreditHours(creditHours);
                                        course.setSemester(semester);
                                        course.setUsername(loggedUser);
                                        RealmResults<Instructor> instructor = realm.where(Instructor.class)
                                                .equalTo("name", getChosenI()).findAll();
                                        course.setInstructor(instructor.first());
                                    }
                                });

                                RealmResults<Course> courses = realm.where(Course.class).findAll();

                                for (Course course : courses) {
                                    Log.d("CreateCourseFragment", "onActivityCreated:" + course.toString());
                                }

                                Toast.makeText(getActivity(), "Course Creation Success", Toast.LENGTH_SHORT).show();


                            } finally {
                                realm.close();
                            }
                            mListener.gotoNextFragment();
                        }
                    }
                    else {
                        Toast.makeText(getActivity(), "Minutes must be between 1 and 59", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Hours must be between 1 and 12", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button btnReset = getView().findViewById(R.id.btnResetInstructors);
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editTitle = getView().findViewById(R.id.editTitle);
                Spinner spinDay = (Spinner)(getView().findViewById(R.id.spinPickDay));
                EditText editHour = getView().findViewById(R.id.editHour);
                EditText editMinutes = getView().findViewById(R.id.editMinutes);
                Spinner spinAMPM = getView().findViewById(R.id.spinPickAMPM);
                RadioGroup radioCredit = getView().findViewById(R.id.radioCourseHours);
                Spinner spinSemester = getView().findViewById(R.id.spinSemester);

                editTitle.setText("");
                spinDay.setSelection(0);
                editHour.setText("");
                editMinutes.setText("");
                spinAMPM.setSelection(0);
                RadioButton radioButton = (RadioButton) radioCredit.getChildAt(0);
                radioButton.setChecked(true);
                spinSemester.setSelection(1);

                Toast.makeText(getActivity(), "Selection has been reset!", Toast.LENGTH_SHORT).show();
            }
        });

    }



    public void setHandlers() {
        List<String> spinnerArray = new ArrayList<String>();
        spinnerArray.add("Monday");
        spinnerArray.add("Tuesday");
        spinnerArray.add("Wednesday");
        spinnerArray.add("Thursday");
        spinnerArray.add("Friday");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_dropdown_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner sItems = (Spinner) getView().findViewById(R.id.spinPickDay);
        sItems.setAdapter(adapter);

        // Create AMPM spinner
        List<String> spinPickAMPMArray = new ArrayList<String>();
        spinPickAMPMArray.add("AM");
        spinPickAMPMArray.add("PM");

        ArrayAdapter<String> spinPickAMPMAdapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_dropdown_item, spinPickAMPMArray);

        spinPickAMPMAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinPickAMPM = (Spinner) getView().findViewById(R.id.spinPickAMPM);
        spinPickAMPM.setAdapter(spinPickAMPMAdapter);

        // Create semester spinner
        List<String> spinSemesterArray = new ArrayList<String>();
        spinSemesterArray.add("Fall 2017");
        spinSemesterArray.add("Spring 2018");
        spinSemesterArray.add("Summer 2018");
        spinSemesterArray.add("Fall 2018");

        ArrayAdapter<String> spinSemesterAdapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_dropdown_item, spinSemesterArray);

        spinSemesterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinSemester = (Spinner) getView().findViewById(R.id.spinSemester);
        spinSemester.setAdapter(spinSemesterAdapter);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof CreateCourseFragment.OnFragmentInteractionListener) {
            mListener = (CreateCourseFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void gotoNextFragment();
    }


}
