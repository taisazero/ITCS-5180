package com.example.zero.inclass13;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class createTrip extends AppCompatActivity {
    RecyclerView placesList;
    placeAdapter placeAdapter;
    LinearLayoutManager lm;
    EditText tripName;
    EditText numPpl;
    TextView cost;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_trip);
        placeAdapter=new placeAdapter(MainActivity.placeList);
        placesList=findViewById(R.id.placesList);
       lm= new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
       placesList.setLayoutManager(lm);
       placesList.setAdapter(placeAdapter);
       tripName=findViewById(R.id.tripText);
       numPpl=findViewById(R.id.numPpl);
       cost=findViewById(R.id.cost);
       setHandlers();

    }
    public void setHandlers(){
        Button viewTrip=findViewById(R.id.viewTrip);
        Button addToTrips=findViewById(R.id.addTrip);
        Button cancel= findViewById(R.id.cancel);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        addToTrips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Trip t= new Trip();
                t.setList(placeAdapter.getJourney());
                double totalCost=0;
                for (Place p: t.getList()){
                    totalCost+=p.getCost();
                }
                t.setName(tripName.getText().toString());
                Double d=new Double(numPpl.getText().toString())*totalCost;
                t.setCost(new Double(numPpl.getText().toString())*totalCost);
                Toast.makeText(createTrip.this,"The cost is "+d.toString(),Toast.LENGTH_LONG).show();
                cost.setText(cost.getText().toString()+" "+d.toString());
            }
        });
        viewTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(createTrip.this,MapsActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}
